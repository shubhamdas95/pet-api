=========

## REST Testing and Examples

### The Course

The "REST With Spring" Classes: http://bit.ly/restwithspring

### Relevant Articles: 

- [Introduction to WireMock](http://www.baeldung.com/introduction-to-wiremock)
- [Using WireMock Scenarios](https://www.baeldung.com/wiremock-scenarios)
- [REST API Testing with Cucumber](http://www.baeldung.com/cucumber-rest-api-testing)
- [Testing a REST API with JBehave](http://www.baeldung.com/jbehave-rest-testing)
- [REST API Testing with Karate](http://www.baeldung.com/karate-rest-api-testing)
